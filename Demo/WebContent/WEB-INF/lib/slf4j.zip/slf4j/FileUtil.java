/**
 * 
 */
package com.citi.citimkts.util.logback;

import java.io.File;

/**
 * @author yg71969
 * 
 */
public class FileUtil extends ch.qos.logback.core.util.FileUtil {
	static public boolean isParentDirectoryCreationRequired(File file) {
		File parent = file.getParentFile();
		if (parent != null && !parent.exists()) {
			return true;
		} else {
			return false;
		}
	}
}
